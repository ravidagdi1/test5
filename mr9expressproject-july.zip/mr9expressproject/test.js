let a = new Date();
let hours=a.getHours()*60;
let mins=a.getMinutes()
let year = a.getFullYear()
let month = a.getMonth() +1;
let day = a.getDate()

let date = day+'/'+month+'/'+year
let IntimeInmin= hours+mins;
let IntimeInhours= (hours+mins)/60;

console.log(Math.round(IntimeInhours));