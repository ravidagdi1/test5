const mongoose =require('mongoose')//module

const parkingSchema =mongoose.Schema({
    vno:String,
    vtype:String,
    inTime:Number,
    outTime:Number,
    amount:Number,
    status:String
});
  

 module.exports= mongoose.model('parking',parkingSchema)