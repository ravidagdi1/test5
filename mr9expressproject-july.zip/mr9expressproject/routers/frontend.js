const router =require('express').Router()
const Banner =require('../models/banner')
const Query =require('../models/query');
const Users =require('../models/users');
const multer =require('multer');
//define storage

const storage= multer.diskStorage({
    destination:function(req,file,callback){
        callback(null,'./public/upload');
    },
    filename:function(req,file,callback){
        callback(null,Date.now()+file.originalname);
    },
})

 const upload=multer({
storage:storage,
limits:{fileSize:1024*1024*4}
});

let sess=null;
function handleChecklogin(req,res,next){
    if(req.session.isAuth){
        next()
    }
    else{
        res.redirect('/Login')
    }
}

function handleRoles(req,res,next){
    if(sess!==null){
    if(sess.role=='pvt'){
        next()
    }else{
        res.redirect('/Login')
    }
    }else{
        res.send("you don't have permission to see this page")
    }
}

router.get('/',handleChecklogin,async(req,res)=>{
   const bannerRecord = await Banner.findOne()
   if(sess!==null){
    res.render('index.ejs',{bannerRecord,username:sess.username})
   }else{
    res.render('index.ejs',{bannerRecord,username:'hello'})
   }
})
router.get('/banner',handleRoles,async(req,res)=>{
    const bannerRecord = await Banner.findOne()
    if(sess!==null){
        res.render('banner.ejs',{bannerRecord,username:sess.username})
       }else{
        res.render('banner.ejs',{bannerRecord,username:'hello'})
       }
});

router.post('/query',async(req,res)=>{
        const {email,query}=req.body
        const status='unread'
       const queryRecord = new Query({email:email,query:query,status:status})
      await queryRecord.save()
      res.redirect('/')
});

router.get('/Login',(req,res)=>{
    res.render('login.ejs')
    if(sess!==null){
        res.render('login.ejs',{username:sess.username})
       }else{
        res.render('login.ejs',{username:'hello'})
       }
});

router.post('/login',async(req,res)=>{
    const {username,password}=req.body
    const userRecord=await Users.findOne({username:username})
    console.log(userRecord)
    if(userRecord !==null){
        if(userRecord.password==password){
            if(userRecord.status!=='suspended'){
                req.session.isAuth=true
                sess=req.session
                sess.username=userRecord.username
                sess.role =userRecord.role
                ///console.log(sess.username)
        res.redirect('/')
            }else{
                res.send("your account is suspended")
            }
        }else{
            res.redirect('/Login')  
        }
    }else{
       res.redirect('/Login') 
    }
})

router.get('/registration',(req,res)=>{
    if(sess!==null){
        res.render('reg.ejs',{username:sess.username})
       }else{
        res.render('reg.ejs',{username:'hello'})
       }
});

router.post('/reg',async(req,res)=>{
    const {username,password}=req.body
      const userRecord=  new Users({username:username,password:password,status:'suspended',role:'public'})
      await userRecord.save()
      res.redirect('/Login')
})

router.get('/logout',(req,res)=>{
    req.session.destroy()
    sess.username='hello'
    sess.role=null
    res.redirect('/Login')
      
    
});
router.get('/img',(req,res)=>{
    res.render('imgform.ejs');
})

router.post('/imgupload',upload.single('img'),(req,res)=>{
    console.log(req.file.filename);
})



module.exports=router;