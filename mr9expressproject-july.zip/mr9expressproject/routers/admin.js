const router =require('express').Router()
const Admin =require('../models/admin');
const Banner =require('../models/banner')
const Query =require('../models/query')
const Users =require('../models/users')
const Parking=require('../models/parking');
const multer =require('multer');

let a = new Date();
let hours=a.getHours()*60;
let mins=a.getMinutes()
let year = a.getFullYear()
let month = a.getMonth() +1;
let day = a.getDate()

let date = day+'/'+month+'/'+year
let IntimeInmin= hours+mins;
let IntimeInhours= (hours+mins)/60;
let hoursInround = Math.round(IntimeInhours);

const storage= multer.diskStorage({
    destination:function(req,file,callback){
        callback(null,'./public/upload');
    },
    filename:function(req,file,callback){
        callback(null,Date.now()+file.originalname);
    },
})

 const upload=multer({
storage:storage,
limits:{fileSize:1024*1024*4}
});


function auth(req,res,next){
    if(req.session.isAuth){
        next();
    }else{
        res.redirect('/admin/')
    }
}

router.get('/',(req,res)=>{
    res.render('admin/login.ejs');
})

router.post('/',async(req,res)=>{
   const{username,password}=req.body;
   const adminrecord = await Admin.findOne({username:username})
   console.log(adminrecord);
   if(adminrecord !==null){
    if(adminrecord.password==password){
        req.session.isAuth =true;
    res.redirect('/admin/dashboard')
    }else{
        res.redirect('/admin/')
    }
   }else{
    res.redirect('/admin/')
   }
});

router.get('/dashboard',auth,(req,res)=>{
    res.render('admin/dashboard.ejs')
});

router.get('/logout',(req,res)=>{
    req.session.destroy();
    res.redirect('/admin/')
});

router.get('/banner',async(req,res)=>{
    const bannerRecord =await Banner.findOne()
    res.render('admin/banner.ejs',{bannerRecord})
})

//--------- insert test url---------

router.get('/test',async(req,res)=>{
   const adminrecord= new Banner({title:'banner',desc:'hello',ldesc:'hhhhh'})
   await adminrecord.save();
});

router.get('/banneredit/:id',async(req,res)=>{
    const id =req.params.id
    const bannerRecord = await Banner.findById(id)
    console.log(bannerRecord)
    res.render('admin/bannerform.ejs',{bannerRecord})
})

router.post('/bannerupdate/:id',upload.single('img'),async(req,res)=>{
    const id = req.params.id
    //const img=req.file.filename;
    console.log(id)
    const {title,sdesc,ldesc}=req.body
    if(req.file){
    await Banner.findByIdAndUpdate(id,{title:title,desc:sdesc,ldesc:ldesc,img:req.file.filename})
    }else{
        await Banner.findByIdAndUpdate(id,{title:title,desc:sdesc,ldesc:ldesc})
    }
    res.redirect('/admin/banner')

});

router.get('/query',async(req,res)=>{
    const queryRecord =await Query.find()
    res.render('admin/query.ejs',{queryRecord})
});

router.get('/queryupdate/:id',async(req,res)=>{
    const id =req.params.id
    const queryRecord= await Query.findById(id)
    console.log(queryRecord);
    let a=null;
    if(queryRecord.status =='unread'){
        a='read'
    }else{
        a='unread'
    }
   await Query.findByIdAndUpdate(id,{status:a})
   res.redirect('/admin/query')
})

router.post('/querysearch',async(req,res)=>{
    const {search}=req.body
    const queryRecord  =await Query.find({status:search})
    res.render('admin/query',{queryRecord})
});

router.get('/users',async(req,res)=>{
       const userRecords = await Users.find()
       console.log(userRecords)
    res.render('admin/users.ejs',{userRecords})
});

router.get('/loginupdate/:id',async(req,res)=>{
    const id =req.params.id
    const userRecord =await Users.findById(id)
    let a=null
    if(userRecord.status=='suspended'){
        a='active'
    }else{
        a='suspended'
    }
    await Users.findByIdAndUpdate(id,{status:a})
    res.redirect('/admin/users')
})

router.get('/roleupdate/:id',async(req,res)=>{
    const id =req.params.id;
  const userRecord = await Users.findById(id)
    console.log(userRecord);
    let role=null;
    if(userRecord.role=='public'){
        role='pvt'
    }else{
        role='public'
    }
    await Users.findByIdAndUpdate(id,{role:role})
    res.redirect('/admin/users')
})

router.get('/parkinginsert',(req,res)=>{
    res.render('admin/parkinginsert.ejs')
});

router.post('/parkingrecords',async(req,res)=>{
    const {vno,vtype}=req.body;
   const parkingREcord= new Parking({vno:vno,vtype,inTime:hoursInround,outTime:0,amount:0,status:'IN'})
   await parkingREcord.save()
   res.redirect('/admin/parkingshow');
})

router.get('/parkingshow',async(req,res)=>{
    const parkingREcords =await Parking.find()
    res.render('admin/parkingshow.ejs',{parkingREcords})
})

router.get('/parkingupdate/:id',async(req,res)=>{
    const id =req.params.id;
    const parkingREcord =  await Parking.findById(id)
    console.log(parkingREcord.vtype)
    const outTime=hoursInround;
    let amount=null;
    if(parkingREcord.vtype=='w2'){
        amount =(outTime-parkingREcord.inTime)*30
    }
    else if(parkingREcord.vtype=='w3'){
        amount =(outTime-parkingREcord.inTime)*50

    }
    else if(parkingREcord.vtype=='w4'){
        amount =(outTime-parkingREcord.inTime)*80
    }
    else if(parkingREcord.vtype=='others'){
        amount =(outTime-parkingREcord.inTime)*100
    }
    await Parking.findByIdAndUpdate(id,{outTime:outTime,amount:amount,status:'OUT'})
    res.redirect('/admin/parkingshow')
});

router.get('/parkingprint/:id',async(req,res)=>{
    const id =req.params.id
   const parkingRecord = await Parking.findById(id)
    res.render('admin/primtpage.ejs',{parkingRecord})
})










module.exports=router;